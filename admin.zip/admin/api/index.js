import * as service from './service'

export default service
